# -*- coding: utf-8 -*-
# Synthetic Python recipe (fixture). Exercises the usual dataiku idioms.
import dataiku
import pandas as pd

variables = dataiku.get_custom_variables()
threshold = float(variables.get("score_threshold", "0.5"))

deliveries = dataiku.Dataset("delivered_enriched").get_dataframe()
stats = dataiku.Dataset("DEMO_SIMPLE.customer_stats").get_dataframe()

df = deliveries.merge(stats, on="customer_id", how="left")
df["score"] = (df["amount_eur_sum"].fillna(0) / (df["delay_minutes"].fillna(0) + 1)).round(3)
df["is_good"] = df["score"] >= threshold

out = dataiku.Dataset("customer_scores")
out.write_with_schema(df[["customer_id", "score", "is_good"]])
